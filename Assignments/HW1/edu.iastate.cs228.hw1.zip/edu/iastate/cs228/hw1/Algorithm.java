package edu.iastate.cs228.hw1;

/**
 * 
 * Four sorting algorithms 
 *
 */
public enum Algorithm 
{
	SelectionSort, InsertionSort, MergeSort, QuickSort
}
